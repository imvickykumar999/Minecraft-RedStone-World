ZQSD : Move the camera (designed for azerty keyboards)

Mouse scroll : Select block

Left shift + Mouse scroll : Zoom / Dezoom

Right click : Place block ; Click on repeaters with the repeater selected to change the delay amount, or on torches with the torch selected to attach them to walls

Left click : Remove block

G : Rotate selected block clockwise

F : Rotate selected block counter-clockwise

Made by Maniacobra